# 屏幕有狼
## 粉糖粒子周周作品 java桌宠

### 简介
一款纯JAVA编写的原创电脑端联网桌面宠物游戏
点击可执行程序即可运行

### 游戏玩法
- 注册粉糖账号以及领养狼
- 在屏幕上与狼自由互动
- assets文件夹中的图片都可以替换

### 文件说明
- jre是java虚拟机 游戏依赖不能移除
- assets是游戏资产
- user 用户文件夹 用于储存session以登录

#### 该游戏应用粉糖粒子许可：署名、非盈利、不封闭

### 关于
- 粉糖粒子官网 pinkcandy.top
- github github.com/ZhouZhou1235
- 作者邮箱 pinkcandyzhou@qq.com
