package pinkcandy.screenwolf;

import pinkcandy.screenwolf.core.Launcher;

/**
 * 游戏程序入口
 * 使用启动器开始！
 */
public class Main {
    public static void main(String[] args){
        new Launcher();
    }
}
